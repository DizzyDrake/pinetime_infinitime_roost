Roost for PineTime - Gadgetbridge installation bundle

Extract this outer bundle, transfer the -DFU.zip file to your Android phone,
and install it with Gadgetbridge. Do not extract the inner DFU ZIP.

Guide: INSTALL_GADGETBRIDGE.md or INSTALL_GADGETBRIDGE.pdf
